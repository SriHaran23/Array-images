import React from 'react';
import Array from './components/Array';

function App() {
  return (
    <div className="imgw">
      <Array></Array>
    </div>
  );
}

export default App;
